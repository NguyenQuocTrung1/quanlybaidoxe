﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Emgu.CV.UI; // Thêm thư viện Emgu.CV.UI để dùng ImageBox

namespace QuanLyBaiDoXe
{
    public partial class Khachvao : Form
    {
        private Button btnCapture;
        private ImageBox imageBox; // Đổi từ PictureBox sang ImageBox
        private TextBox txtName;
        private TextBox txtPlateNumber; // Đổi tên biến từ textBox1
        private Label label1;
        private Label label2;

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Khachvao));
            btnCapture = new Button();
            imageBox = new ImageBox();
            txtName = new TextBox();
            txtPlateNumber = new TextBox();
            label1 = new Label();
            label2 = new Label();
            lblCheckInTime = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)imageBox).BeginInit();
            SuspendLayout();
            // 
            // btnCapture
            // 
            btnCapture.Location = new Point(159, 360);
            btnCapture.Name = "btnCapture";
            btnCapture.Size = new Size(100, 40);
            btnCapture.TabIndex = 4;
            btnCapture.Text = "Chụp ảnh";
            btnCapture.Click += btnCapture_Click_1;
            // 
            // imageBox
            // 
            imageBox.BackColor = SystemColors.Info;
            imageBox.BorderStyle = BorderStyle.FixedSingle;
            imageBox.Location = new Point(31, 44);
            imageBox.Name = "imageBox";
            imageBox.Size = new Size(400, 300);
            imageBox.SizeMode = PictureBoxSizeMode.StretchImage;
            imageBox.TabIndex = 2;
            imageBox.TabStop = false;
            // 
            // txtName
            // 
            txtName.Location = new Point(550, 100);
            txtName.Name = "txtName";
            txtName.PlaceholderText = "Nhập tên...";
            txtName.Size = new Size(200, 27);
            txtName.TabIndex = 3;
            // 
            // txtPlateNumber
            // 
            txtPlateNumber.Location = new Point(550, 150);
            txtPlateNumber.Name = "txtPlateNumber";
            txtPlateNumber.PlaceholderText = "Nhập biển số...";
            txtPlateNumber.Size = new Size(200, 27);
            txtPlateNumber.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(506, 100);
            label1.Name = "label1";
            label1.Size = new Size(34, 19);
            label1.TabIndex = 6;
            label1.Text = "Tên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(487, 153);
            label2.Name = "label2";
            label2.Size = new Size(61, 19);
            label2.TabIndex = 7;
            label2.Text = "Biển số";
            // 
            // lblCheckInTime
            // 
            lblCheckInTime.AutoSize = true;
            lblCheckInTime.Location = new Point(591, 193);
            lblCheckInTime.Name = "lblCheckInTime";
            lblCheckInTime.Size = new Size(0, 19);
            lblCheckInTime.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(550, 44);
            label3.Name = "label3";
            label3.Size = new Size(151, 19);
            label3.TabIndex = 9;
            label3.Text = "Thông tin khách hàng";
            // 
            // Khachvao
            // 
            AutoSize = true;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(982, 503);
            Controls.Add(label3);
            Controls.Add(lblCheckInTime);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtPlateNumber);
            Controls.Add(txtName);
            Controls.Add(imageBox);
            Controls.Add(btnCapture);
            Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "Khachvao";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Face Recognition";
            Load += Khachvao_Load;
            ((System.ComponentModel.ISupportInitialize)imageBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }


        // Thêm phương thức xử lý sự kiện Load
        private void Khachvao_Load(object sender, EventArgs e)
        {
            lblCheckInTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }


        private System.ComponentModel.IContainer components;

        // Sự kiện TextChanged của txtPlateNumber
        private void TxtPlateNumber_TextChanged(object sender, EventArgs e)
        {
            // Xử lý khi biển số thay đổi (nếu cần)
        }
        private Label lblCheckInTime;
        private Label label3;
    }
}
