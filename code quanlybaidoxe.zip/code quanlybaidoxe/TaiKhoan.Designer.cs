﻿namespace QuanLyBaiDoXe
{
    partial class TaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TaiKhoan));
            btnDangnhap = new Button();
            btnDangky = new Button();
            txtTenDangNhap = new TextBox();
            txtMatKhau = new TextBox();
            label1 = new Label();
            label2 = new Label();
            lblVaiTro = new Label();
            cmbVaiTro = new ComboBox();
            lblTitle = new Label();
            btnSwitchToDangNhap = new Button();
            btnSwitchToDangKy = new Button();
            SuspendLayout();
            // 
            // btnDangnhap
            // 
            btnDangnhap.Location = new Point(425, 331);
            btnDangnhap.Name = "btnDangnhap";
            btnDangnhap.Size = new Size(106, 28);
            btnDangnhap.TabIndex = 0;
            btnDangnhap.Text = "Đăng nhập";
            btnDangnhap.UseVisualStyleBackColor = true;
            btnDangnhap.Click += btnDangnhap_Click;
            // 
            // btnDangky
            // 
            btnDangky.Location = new Point(425, 331);
            btnDangky.Name = "btnDangky";
            btnDangky.Size = new Size(106, 28);
            btnDangky.TabIndex = 1;
            btnDangky.Text = "Đăng ký";
            btnDangky.UseVisualStyleBackColor = true;
            btnDangky.Click += btnDangky_Click;
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.Location = new Point(350, 206);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.Size = new Size(260, 27);
            txtTenDangNhap.TabIndex = 3;
            // 
            // txtMatKhau
            // 
            txtMatKhau.Location = new Point(350, 260);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.Size = new Size(260, 27);
            txtMatKhau.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(295, 209);
            label1.Name = "label1";
            label1.Size = new Size(42, 19);
            label1.TabIndex = 5;
            label1.Text = "User";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(263, 263);
            label2.Name = "label2";
            label2.Size = new Size(74, 19);
            label2.TabIndex = 6;
            label2.Text = "Password";
            // 
            // lblVaiTro
            // 
            lblVaiTro.AutoSize = true;
            lblVaiTro.Location = new Point(283, 153);
            lblVaiTro.Name = "lblVaiTro";
            lblVaiTro.Size = new Size(54, 19);
            lblVaiTro.TabIndex = 7;
            lblVaiTro.Text = "Vai trò";
            // 
            // cmbVaiTro
            // 
            cmbVaiTro.FormattingEnabled = true;
            cmbVaiTro.Items.AddRange(new object[] { "Admin", "NhanVien" });
            cmbVaiTro.Location = new Point(350, 150);
            cmbVaiTro.Name = "cmbVaiTro";
            cmbVaiTro.Size = new Size(260, 27);
            cmbVaiTro.TabIndex = 8;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(425, 47);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(0, 31);
            lblTitle.TabIndex = 9;
            // 
            // btnSwitchToDangNhap
            // 
            btnSwitchToDangNhap.BackgroundImage = (Image)resources.GetObject("btnSwitchToDangNhap.BackgroundImage");
            btnSwitchToDangNhap.ForeColor = SystemColors.ButtonFace;
            btnSwitchToDangNhap.Location = new Point(768, 47);
            btnSwitchToDangNhap.Name = "btnSwitchToDangNhap";
            btnSwitchToDangNhap.Size = new Size(106, 28);
            btnSwitchToDangNhap.TabIndex = 10;
            btnSwitchToDangNhap.Text = "Đăng Nhập";
            btnSwitchToDangNhap.UseVisualStyleBackColor = true;
            btnSwitchToDangNhap.Click += btnSwitchToDangNhap_Click;
            // 
            // btnSwitchToDangKy
            // 
            btnSwitchToDangKy.BackgroundImage = (Image)resources.GetObject("btnSwitchToDangKy.BackgroundImage");
            btnSwitchToDangKy.Location = new Point(768, 47);
            btnSwitchToDangKy.Name = "btnSwitchToDangKy";
            btnSwitchToDangKy.Size = new Size(106, 28);
            btnSwitchToDangKy.TabIndex = 11;
            btnSwitchToDangKy.Text = "Đăng ký";
            btnSwitchToDangKy.UseVisualStyleBackColor = true;
            btnSwitchToDangKy.Click += btnSwitchToDangKy_Click;
            // 
            // TaiKhoan
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(982, 503);
            Controls.Add(btnSwitchToDangKy);
            Controls.Add(btnSwitchToDangNhap);
            Controls.Add(lblTitle);
            Controls.Add(cmbVaiTro);
            Controls.Add(lblVaiTro);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtMatKhau);
            Controls.Add(txtTenDangNhap);
            Controls.Add(btnDangky);
            Controls.Add(btnDangnhap);
            Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "TaiKhoan";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TaiKhoan";
            Load += TaiKhoan_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnDangnhap;
        private Button btnDangky;
        private TextBox txtTenDangNhap;
        private TextBox txtMatKhau;
        private Label label1;
        private Label label2;
        private Label lblVaiTro;
        private ComboBox cmbVaiTro;
        private Label lblTitle;
        private Button btnSwitchToDangNhap;
        private Button btnSwitchToDangKy;
    }
}