﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using Microsoft.Data.SqlClient;

namespace QuanLyBaiDoXe
{
    public partial class Khachvao : Form
    {
        private VideoCapture? _capture;
        private CascadeClassifier? _faceCascade;
        private readonly string connectionString = "Server=NGUYENQUOCTRUNG\\SQLEXPRESS04;Database=face_db;Trusted_Connection=True;TrustServerCertificate=True;";

        public Khachvao()
        {
            InitializeComponent();
            string faceCascadePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "haarcascade_frontalface_default.xml");
            if (File.Exists(faceCascadePath))
            {
                _faceCascade = new CascadeClassifier(faceCascadePath);
            }
            InitCamera();
        }

        private void InitCamera()
        {
            _capture = new VideoCapture(0);
            if (_capture != null && _capture.IsOpened)
            {
                _capture.ImageGrabbed += ProcessFrame;
                _capture.Start();
            }
        }

        private void ProcessFrame(object? sender, EventArgs e)
        {
            if (_capture == null || _faceCascade == null) return;

            Mat frame = new Mat();
            _capture.Retrieve(frame);
            if (frame.IsEmpty) return;

            Image<Bgr, byte> image = frame.ToImage<Bgr, byte>();
            var grayImage = image.Convert<Gray, byte>();
            var faces = _faceCascade.DetectMultiScale(grayImage, 1.1, 10, new Size(50, 50));

            foreach (var face in faces)
            {
                image.Draw(face, new Bgr(Color.Red), 2);
            }

            imageBox.Image = image;
        }
        private void SaveFaceToDatabase(Bitmap faceImage, string personName, string plateNumber)
        {
            try
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    faceImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    byte[] imageBytes = ms.ToArray();

                    string query = "INSERT INTO faces (name, plate_number, image) VALUES (@name, @plate_number, @image)";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = personName;
                        cmd.Parameters.Add("@plate_number", SqlDbType.NVarChar).Value = plateNumber;
                        cmd.Parameters.Add("@image", SqlDbType.VarBinary).Value = imageBytes;

                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Dữ liệu đã được lưu vào database.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Không thể lưu vào database!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            _capture?.Stop();
            _capture?.Dispose();
        }

        private void btnCapture_Click_1(object sender, EventArgs e)
        {
            if (_capture == null)
            {
                MessageBox.Show("Camera chưa được khởi động!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Mat frame = new Mat();
            _capture.Retrieve(frame);

            if (frame.IsEmpty)
            {
                MessageBox.Show("Không lấy được ảnh từ camera!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string personName = txtName.Text.Trim();
            string plateNumber = txtPlateNumber.Text.Trim();

            if (string.IsNullOrEmpty(personName) || string.IsNullOrEmpty(plateNumber))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tên và biển số xe!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Bitmap faceImage = frame.ToImage<Bgr, byte>().ToBitmap();

            // 1️⃣ Lưu ảnh khuôn mặt vào `faces`
            SaveFaceToDatabase(faceImage, personName, plateNumber);

            // 2️⃣ Lưu thông tin vào `parking_history`
            SaveParkingHistory(personName, plateNumber);

            MessageBox.Show("Lưu ảnh và thời gian vào thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    
    private void SaveParkingHistory(string personName, string plateNumber)
        {
            try
            {
                string query = "INSERT INTO parking_history (owner_name, plate_number, check_in) VALUES (@owner_name, @plate_number, GETDATE())";

                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.Add("@owner_name", SqlDbType.NVarChar).Value = personName;
                    cmd.Parameters.Add("@plate_number", SqlDbType.NVarChar).Value = plateNumber;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi lưu vào parking_history: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
