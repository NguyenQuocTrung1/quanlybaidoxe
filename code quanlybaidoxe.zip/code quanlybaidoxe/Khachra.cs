﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.Structure;
using Microsoft.Data.SqlClient;
using Emgu.CV.CvEnum;
using Emgu.CV.Face;
using Emgu.CV.Util;
using System.Diagnostics;

namespace QuanLyBaiDoXe
{
    public partial class Khachra : Form
    {
        private LBPHFaceRecognizer? _faceRecognizer;
        private VideoCapture? _capture;
        private CascadeClassifier? _faceCascade;
        private readonly string connectionString = "Server=NGUYENQUOCTRUNG\\SQLEXPRESS04;Database=face_db;Trusted_Connection=True;TrustServerCertificate=True;";
        private Image<Bgr, byte>? databaseFaceImage;

        public Khachra()
        {
            InitializeComponent();
            string faceCascadePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "haarcascade_frontalface_default.xml");
            if (File.Exists(faceCascadePath))
            {
                _faceCascade = new CascadeClassifier(faceCascadePath);
            }
            InitCamera();
        }

        private void InitCamera()
        {
            _capture = new VideoCapture(0);
            if (_capture != null && _capture.IsOpened)
            {
                _capture.ImageGrabbed += ProcessFrame;
                _capture.Start();
            }
        }


        private void ProcessFrame(object? sender, EventArgs e)
        {
            if (_capture == null || _faceCascade == null) return;

            Mat frame = new Mat();
            _capture.Retrieve(frame);
            if (frame.IsEmpty) return;

            Image<Bgr, byte> image = frame.ToImage<Bgr, byte>();
            var grayImage = image.Convert<Gray, byte>();
            var faces = _faceCascade.DetectMultiScale(grayImage, 1.1, 10, new Size(50, 50));

            foreach (var face in faces)
            {
                image.Draw(face, new Bgr(Color.Red), 2);
            }

            // Thay thế ImageBox bằng PictureBox
            imgKhachHang.Image = image.ToBitmap();
        }

        private bool CompareFaces(Image<Bgr, byte> faceToCompare)
        {
            if (_faceRecognizer == null || _faceCascade == null) return false;

            try
            {
                using (Image<Gray, byte> grayFace = faceToCompare.Convert<Gray, byte>())
                {
                    Rectangle[] faces = _faceCascade.DetectMultiScale(grayFace, 1.1, 10, new Size(50, 50));
                    if (faces.Length == 0) return false;

                    using (Image<Gray, byte> croppedFace = grayFace.Copy(faces[0]))
                    using (Image<Gray, byte> processedFace = PreprocessFace(croppedFace))
                    {
                        FaceRecognizer.PredictionResult result = _faceRecognizer.Predict(processedFace);
                        Console.WriteLine($"Distance: {result.Distance}");
                        return result.Distance < 50;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi CompareFaces: {ex.Message}");
                return false;
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            _capture?.Stop();
            _capture?.Dispose();
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string bienSoXe = txtBienSo.Text.Trim();
            if (string.IsNullOrEmpty(bienSoXe))
            {
                MessageBox.Show("Vui lòng nhập biển số xe!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT name, image FROM faces WHERE plate_number = @bienSoXe";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@bienSoXe", bienSoXe);
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            lblThongTinXe.Text = $"Biển số: {bienSoXe} - Chủ xe: {reader["name"]}";

                            byte[] imageBytes = (byte[])reader["image"];
                            using (MemoryStream ms = new MemoryStream(imageBytes))
                            {
                                Bitmap bitmap = new Bitmap(ms);
                                databaseFaceImage = bitmap.ToImage<Bgr, byte>();
                                imgKhachHang.Image = databaseFaceImage.ToBitmap();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy thông tin xe!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            TrainRecognizer();
        }

        private void TrainRecognizer()
        {
            List<Image<Gray, byte>> trainingImages = new List<Image<Gray, byte>>();
            List<int> labels = new List<int>();

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT id, image FROM faces";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            byte[] imageBytes = (byte[])reader["image"];
                            using (MemoryStream ms = new MemoryStream(imageBytes))
                            {
                                Bitmap bitmap = new Bitmap(ms);
                                Mat matImage = bitmap.ToMat();
                                Image<Gray, byte> grayImage = matImage.ToImage<Gray, byte>();

                                // Thêm tiền xử lý ảnh train
                                grayImage = PreprocessFace(grayImage);

                                trainingImages.Add(grayImage);
                                labels.Add(reader.GetInt32(0)); // Lấy ID làm nhãn

                                // Debug log
                                Console.WriteLine($"Added training image - Label: {reader.GetInt32(0)}, Size: {grayImage.Width}x{grayImage.Height}");
                            }
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu khuôn mặt: " + ex.Message);
                return;
            }

            if (trainingImages.Count > 0)
            {
                _faceRecognizer = new LBPHFaceRecognizer(1, 8, 8, 8, 100);
                using (VectorOfMat vecImages = new VectorOfMat())
                using (VectorOfInt vecLabels = new VectorOfInt())
                {
                    foreach (var img in trainingImages)
                    {
                        vecImages.Push(img.Mat);
                    }
                    vecLabels.Push(labels.ToArray());

                    _faceRecognizer.Train(vecImages, vecLabels);
                }
            }
        }



        private void btnXacNhan_Click_1(object sender, EventArgs e)
        {
            if (databaseFaceImage == null)
            {
                MessageBox.Show("Chưa xác nhận khuôn mặt! Vui lòng quét lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string bienSoXe = txtBienSo.Text.Trim();
            if (string.IsNullOrEmpty(bienSoXe))
            {
                MessageBox.Show("Vui lòng nhập biển số xe!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string checkQuery = "SELECT check_out FROM parking_history WHERE plate_number = @bienSoXe";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@bienSoXe", bienSoXe);
                        object result = checkCmd.ExecuteScalar();

                        if (result != DBNull.Value && result != null)
                        {
                            MessageBox.Show("Xe này đã được lấy ra trước đó!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    string updateQuery = "UPDATE parking_history SET check_out = GETDATE() WHERE plate_number = @bienSoXe AND check_out IS NULL";
                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        updateCmd.Parameters.AddWithValue("@bienSoXe", bienSoXe);
                        int rowsAffected = updateCmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Xe đã được xác nhận lấy ra!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtBienSo.Clear();
                            imgKhachHang.Image = null;
                        }
                        else
                        {
                            MessageBox.Show("Không thể cập nhật! Xe không tồn tại hoặc đã được lấy ra trước đó.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnQuetKhuonMat_Click(object sender, EventArgs e)
        {
            if (_capture == null || _faceCascade == null)
            {
                MessageBox.Show("Camera chưa khởi động hoặc thiếu file cascade!");
                return;
            }

            try
            {
                using (Mat frame = new Mat())
                {
                    _capture.Retrieve(frame);
                    if (frame.IsEmpty) return;

                    using (Image<Bgr, byte> capturedFace = frame.ToImage<Bgr, byte>())
                    {
                        // Hiển thị ảnh gốc
                        imgKhachHang.Image = capturedFace.ToBitmap();

                        // Detect và crop mặt
                        using (Image<Gray, byte> grayFace = capturedFace.Convert<Gray, byte>())
                        {
                            Rectangle[] faces = _faceCascade.DetectMultiScale(grayFace, 1.1, 10, new Size(50, 50));
                            if (faces.Length > 0)
                            {
                                using (Image<Gray, byte> croppedFace = grayFace.Copy(faces[0]))
                                {
                                    // Thêm phần debug hiển thị ảnh đã crop
                                    if (imgDebug != null)
                                        imgDebug.Image = croppedFace.ToBitmap();

                                    // Preprocess the face before comparison
                                    Image<Gray, byte> processedFace = PreprocessFace(croppedFace);

                                    // Debug: Show the preprocessed face
                                    if (imgDebug != null)
                                        imgDebug.Image = processedFace.ToBitmap();

                                    // So sánh khuôn mặt
                                    bool isMatch = CompareFaces(capturedFace);
                                    MessageBox.Show(isMatch ? "Không!" : "Khớp!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Không tìm thấy khuôn mặt!");
                            }
                        }
                    }
                }
            }
            catch (AccessViolationException ex)
            {
                MessageBox.Show($"Lỗi truy cập bộ nhớ: {ex.Message}\nHãy khởi động lại ứng dụng.");
            }
        }
        // Thêm vào class Khachra (phần khai báo methods)
        private Image<Gray, byte> PreprocessFace(Image<Gray, byte> faceImage)
        {
            // Resize về kích thước chuẩn
            faceImage = faceImage.Resize(100, 100, Inter.Cubic);

            // Cân bằng sáng để tăng độ tương phản
            CvInvoke.EqualizeHist(faceImage, faceImage);

            return faceImage;
        }

    }
}