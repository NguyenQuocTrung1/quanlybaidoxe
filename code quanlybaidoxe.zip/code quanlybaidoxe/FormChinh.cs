﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBaiDoXe
{
    public partial class FormChinh : Form
    {
        private readonly string connectionString = "Server=NGUYENQUOCTRUNG\\SQLEXPRESS04;Database=face_db;Trusted_Connection=True;TrustServerCertificate=True;";
        private string userRole;

        public FormChinh(string role)
        {
            InitializeComponent();
            userRole = role ?? "Nhân Viên";
            PhanQuyen();
            LoadNhanVien();
        }
        private void LoadNhanVien(string keyword = "")
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT id, ten_dang_nhap, mat_khau, vai_tro FROM nguoi_dung";
                if (!string.IsNullOrEmpty(keyword))
                    query += " WHERE ten_dang_nhap LIKE @keyword";

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.SelectCommand.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvNhanVien.DataSource = dt;
            }
        }

        private void btnTimKiemNhanVien_Click(object sender, EventArgs e)
        {
            LoadNhanVien(txtTimKiemNhanVien.Text.Trim());
        }


        private void PhanQuyen()
        {
            if (userRole == "Admin")
            {
                tabControlAdmin.Visible = true;
                pictureBoxBackground.Visible = false;
            }
            else
            {
                tabControlAdmin.Visible = false;
                pictureBoxBackground.Visible = true;


                if (pictureBoxBackground.Image == null)
                {
                    string imagePath = Path.Combine(Application.StartupPath, "Ảnh", "anya.jpg");
                    pictureBoxBackground.Image = Image.FromFile(imagePath);
                    pictureBoxBackground.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBoxBackground.SizeMode = PictureBoxSizeMode.StretchImage; // Tùy chỉnh hiển thị
                }
            }
        }



        private void OpenChildForm(Form childForm)
        {
            this.Hide();
            childForm.FormClosed += (s, args) => this.Show();
            childForm.ShowDialog();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnKhachVao_Click_1(object sender, EventArgs e)
        {
            OpenChildForm(new QuanLyBaiDoXe.Khachvao());
        }

        private void btnKhachRa_Click(object sender, EventArgs e)
        {
            OpenChildForm(new QuanLyBaiDoXe.Khachra());
        }

        private void btnQLBaiDoXe_Click(object sender, EventArgs e)
        {
            OpenChildForm(new QuanLyBaiDoXe.QuanLyBaiDo());
        }

        private void btnTaiKhoan_Click(object sender, EventArgs e)
        {
            OpenChildForm(new QuanLyBaiDoXe.TaiKhoan());
        }

        private void FormChinh_Load_1(object sender, EventArgs e)
        {

        }

        private void btnKhachChu_Click(object sender, EventArgs e)
        {
            OpenChildForm(new QuanLyBaiDoXe.TrangChu());
        }

        private void btnTimKiemNhanVien_Click_1(object sender, EventArgs e)
        {
            LoadNhanVien(txtTimKiemNhanVien.Text.Trim());
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dgvNhanVien.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvNhanVien.SelectedRows[0]; // Sửa lỗi thiếu biến row

                int id = Convert.ToInt32(row.Cells["id"].Value);
                string tenDangNhap = row.Cells["ten_dang_nhap"].Value?.ToString() ?? "";
                string matKhau = row.Cells["mat_khau"].Value?.ToString() ?? "";
                string vaiTro = row.Cells["vai_tro"].Value?.ToString() ?? "";

                if (string.IsNullOrWhiteSpace(tenDangNhap) || string.IsNullOrWhiteSpace(matKhau) || string.IsNullOrWhiteSpace(vaiTro))
                {
                    MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE nguoi_dung SET ten_dang_nhap = @ten, mat_khau = @mk, vai_tro = @vt WHERE id = @id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ten", tenDangNhap);
                    cmd.Parameters.AddWithValue("@mk", matKhau);  // Nên mã hóa mật khẩu trước khi lưu
                    cmd.Parameters.AddWithValue("@vt", vaiTro);
                    cmd.Parameters.AddWithValue("@id", id);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Cập nhật nhân viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadNhanVien();
                    }
                    else
                    {
                        MessageBox.Show("Không thể cập nhật!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một nhân viên để sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvNhanVien.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvNhanVien.SelectedRows[0]; // Sửa lỗi thiếu biến row
                int id = Convert.ToInt32(row.Cells["id"].Value);

                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa nhân viên này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        string query = "DELETE FROM nguoi_dung WHERE id = @id";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@id", id);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Xóa nhân viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadNhanVien();
                        }
                        else
                        {
                            MessageBox.Show("Không thể xóa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một nhân viên để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
