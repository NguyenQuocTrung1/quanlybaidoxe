﻿namespace QuanLyBaiDoXe
{
    partial class QuanLyBaiDo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLyBaiDo));
            dgvXeGui = new DataGridView();
            txtChuXe = new TextBox();
            btnTimKiem = new Button();
            btnXoa = new Button();
            btnLamMoi = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvXeGui).BeginInit();
            SuspendLayout();
            // 
            // dgvXeGui
            // 
            dgvXeGui.BackgroundColor = SystemColors.HotTrack;
            dgvXeGui.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvXeGui.Location = new Point(216, 95);
            dgvXeGui.Name = "dgvXeGui";
            dgvXeGui.RowHeadersWidth = 51;
            dgvXeGui.Size = new Size(633, 303);
            dgvXeGui.TabIndex = 0;
            // 
            // txtChuXe
            // 
            txtChuXe.Location = new Point(216, 51);
            txtChuXe.Name = "txtChuXe";
            txtChuXe.Size = new Size(502, 27);
            txtChuXe.TabIndex = 1;
            // 
            // btnTimKiem
            // 
            btnTimKiem.BackColor = Color.DeepSkyBlue;
            btnTimKiem.Location = new Point(757, 53);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(106, 28);
            btnTimKiem.TabIndex = 2;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = false;
            // 
            // btnXoa
            // 
            btnXoa.BackColor = Color.NavajoWhite;
            btnXoa.BackgroundImageLayout = ImageLayout.Stretch;
            btnXoa.ForeColor = SystemColors.ControlText;
            btnXoa.Location = new Point(79, 198);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(106, 28);
            btnXoa.TabIndex = 5;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = false;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnLamMoi
            // 
            btnLamMoi.BackColor = Color.NavajoWhite;
            btnLamMoi.Location = new Point(79, 256);
            btnLamMoi.Name = "btnLamMoi";
            btnLamMoi.Size = new Size(106, 28);
            btnLamMoi.TabIndex = 6;
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.UseVisualStyleBackColor = false;
            btnLamMoi.Click += btnLamMoi_Click;
            // 
            // QuanLyBaiDo
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(982, 503);
            Controls.Add(btnLamMoi);
            Controls.Add(btnXoa);
            Controls.Add(btnTimKiem);
            Controls.Add(txtChuXe);
            Controls.Add(dgvXeGui);
            Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "QuanLyBaiDo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "QuanLyBaiDo";
            Load += QuanLyBaiDo_Load;
            ((System.ComponentModel.ISupportInitialize)dgvXeGui).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvXeGui;
        private TextBox txtChuXe;
        private Button btnTimKiem;
        private Button btnXoa;
        private Button btnLamMoi;
    }
}