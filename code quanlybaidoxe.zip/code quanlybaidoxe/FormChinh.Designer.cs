﻿namespace QuanLyBaiDoXe
{
    partial class FormChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormChinh));
            flowLayoutPanel1 = new FlowLayoutPanel();
            btnKhachChu = new Button();
            btnKhachVao = new Button();
            btnKhachRa = new Button();
            btnQLBaiDoXe = new Button();
            btnTaiKhoan = new Button();
            tabQLNhanVien = new TabPage();
            btnXoa = new Button();
            btnSua = new Button();
            btnTimKiemNhanVien = new Button();
            txtTimKiemNhanVien = new TextBox();
            dgvNhanVien = new DataGridView();
            tabControlAdmin = new TabControl();
            pictureBoxBackground = new PictureBox();
            flowLayoutPanel1.SuspendLayout();
            tabQLNhanVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).BeginInit();
            tabControlAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxBackground).BeginInit();
            SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = SystemColors.ActiveBorder;
            flowLayoutPanel1.Controls.Add(btnKhachChu);
            flowLayoutPanel1.Controls.Add(btnKhachVao);
            flowLayoutPanel1.Controls.Add(btnKhachRa);
            flowLayoutPanel1.Controls.Add(btnQLBaiDoXe);
            flowLayoutPanel1.Controls.Add(btnTaiKhoan);
            flowLayoutPanel1.Dock = DockStyle.Top;
            flowLayoutPanel1.Location = new Point(0, 0);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(982, 48);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // btnKhachChu
            // 
            btnKhachChu.Font = new Font("Times New Roman", 10.2F);
            btnKhachChu.ForeColor = Color.Snow;
            btnKhachChu.Image = (Image)resources.GetObject("btnKhachChu.Image");
            btnKhachChu.Location = new Point(3, 3);
            btnKhachChu.Name = "btnKhachChu";
            btnKhachChu.Size = new Size(177, 38);
            btnKhachChu.TabIndex = 0;
            btnKhachChu.Text = "Trang chủ";
            btnKhachChu.UseVisualStyleBackColor = true;
            btnKhachChu.Click += btnKhachChu_Click;
            // 
            // btnKhachVao
            // 
            btnKhachVao.Dock = DockStyle.Left;
            btnKhachVao.Font = new Font("Times New Roman", 10.2F);
            btnKhachVao.ForeColor = Color.Snow;
            btnKhachVao.Image = (Image)resources.GetObject("btnKhachVao.Image");
            btnKhachVao.Location = new Point(186, 3);
            btnKhachVao.Name = "btnKhachVao";
            btnKhachVao.Size = new Size(179, 38);
            btnKhachVao.TabIndex = 1;
            btnKhachVao.Text = "Khách vào";
            btnKhachVao.UseVisualStyleBackColor = true;
            btnKhachVao.Click += btnKhachVao_Click_1;
            // 
            // btnKhachRa
            // 
            btnKhachRa.Dock = DockStyle.Left;
            btnKhachRa.Font = new Font("Times New Roman", 10.2F);
            btnKhachRa.ForeColor = Color.Snow;
            btnKhachRa.Image = (Image)resources.GetObject("btnKhachRa.Image");
            btnKhachRa.Location = new Point(371, 3);
            btnKhachRa.Name = "btnKhachRa";
            btnKhachRa.Size = new Size(179, 38);
            btnKhachRa.TabIndex = 2;
            btnKhachRa.Text = "Khách ra";
            btnKhachRa.UseVisualStyleBackColor = true;
            btnKhachRa.Click += btnKhachRa_Click;
            // 
            // btnQLBaiDoXe
            // 
            btnQLBaiDoXe.Dock = DockStyle.Left;
            btnQLBaiDoXe.Font = new Font("Times New Roman", 10.2F);
            btnQLBaiDoXe.ForeColor = Color.Snow;
            btnQLBaiDoXe.Image = (Image)resources.GetObject("btnQLBaiDoXe.Image");
            btnQLBaiDoXe.Location = new Point(556, 3);
            btnQLBaiDoXe.Name = "btnQLBaiDoXe";
            btnQLBaiDoXe.Size = new Size(235, 38);
            btnQLBaiDoXe.TabIndex = 3;
            btnQLBaiDoXe.Text = "Quản lý bãi đỗ xe";
            btnQLBaiDoXe.UseVisualStyleBackColor = true;
            btnQLBaiDoXe.Click += btnQLBaiDoXe_Click;
            // 
            // btnTaiKhoan
            // 
            btnTaiKhoan.Dock = DockStyle.Left;
            btnTaiKhoan.Font = new Font("Times New Roman", 10.2F);
            btnTaiKhoan.ForeColor = Color.Snow;
            btnTaiKhoan.Image = (Image)resources.GetObject("btnTaiKhoan.Image");
            btnTaiKhoan.Location = new Point(797, 3);
            btnTaiKhoan.Name = "btnTaiKhoan";
            btnTaiKhoan.Size = new Size(179, 38);
            btnTaiKhoan.TabIndex = 4;
            btnTaiKhoan.Text = "Tài khoản";
            btnTaiKhoan.UseVisualStyleBackColor = true;
            btnTaiKhoan.Click += btnTaiKhoan_Click;
            // 
            // tabQLNhanVien
            // 
            tabQLNhanVien.Controls.Add(btnXoa);
            tabQLNhanVien.Controls.Add(btnSua);
            tabQLNhanVien.Controls.Add(btnTimKiemNhanVien);
            tabQLNhanVien.Controls.Add(txtTimKiemNhanVien);
            tabQLNhanVien.Controls.Add(dgvNhanVien);
            tabQLNhanVien.Location = new Point(4, 28);
            tabQLNhanVien.Name = "tabQLNhanVien";
            tabQLNhanVien.Padding = new Padding(3);
            tabQLNhanVien.Size = new Size(974, 423);
            tabQLNhanVien.TabIndex = 0;
            tabQLNhanVien.Text = "Quản lý nhân viên";
            tabQLNhanVien.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            btnXoa.Location = new Point(149, 312);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(94, 29);
            btnXoa.TabIndex = 5;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnSua
            // 
            btnSua.Location = new Point(149, 256);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(94, 29);
            btnSua.TabIndex = 4;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnTimKiemNhanVien
            // 
            btnTimKiemNhanVien.Location = new Point(782, 18);
            btnTimKiemNhanVien.Name = "btnTimKiemNhanVien";
            btnTimKiemNhanVien.Size = new Size(94, 29);
            btnTimKiemNhanVien.TabIndex = 3;
            btnTimKiemNhanVien.Text = "Tìm kiếm";
            btnTimKiemNhanVien.UseVisualStyleBackColor = true;
            btnTimKiemNhanVien.Click += btnTimKiemNhanVien_Click_1;
            // 
            // txtTimKiemNhanVien
            // 
            txtTimKiemNhanVien.Location = new Point(264, 20);
            txtTimKiemNhanVien.Name = "txtTimKiemNhanVien";
            txtTimKiemNhanVien.Size = new Size(494, 27);
            txtTimKiemNhanVien.TabIndex = 2;
            // 
            // dgvNhanVien
            // 
            dgvNhanVien.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvNhanVien.Location = new Point(264, 55);
            dgvNhanVien.Name = "dgvNhanVien";
            dgvNhanVien.RowHeadersWidth = 51;
            dgvNhanVien.Size = new Size(610, 311);
            dgvNhanVien.TabIndex = 1;
            // 
            // tabControlAdmin
            // 
            tabControlAdmin.Controls.Add(tabQLNhanVien);
            tabControlAdmin.Dock = DockStyle.Fill;
            tabControlAdmin.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabControlAdmin.ImeMode = ImeMode.Off;
            tabControlAdmin.Location = new Point(0, 48);
            tabControlAdmin.Name = "tabControlAdmin";
            tabControlAdmin.SelectedIndex = 0;
            tabControlAdmin.Size = new Size(982, 455);
            tabControlAdmin.TabIndex = 1;
            tabControlAdmin.Visible = false;
            // 
            // pictureBoxBackground
            // 
            pictureBoxBackground.Dock = DockStyle.Fill;
            pictureBoxBackground.Location = new Point(0, 48);
            pictureBoxBackground.Name = "pictureBoxBackground";
            pictureBoxBackground.Size = new Size(982, 455);
            pictureBoxBackground.TabIndex = 2;
            pictureBoxBackground.TabStop = false;
            pictureBoxBackground.Click += pictureBox1_Click;
            // 
            // FormChinh
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 503);
            Controls.Add(pictureBoxBackground);
            Controls.Add(tabControlAdmin);
            Controls.Add(flowLayoutPanel1);
            Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "FormChinh";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormChinh";
            Load += FormChinh_Load_1;
            flowLayoutPanel1.ResumeLayout(false);
            tabQLNhanVien.ResumeLayout(false);
            tabQLNhanVien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).EndInit();
            tabControlAdmin.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBoxBackground).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel flowLayoutPanel1;
        private Button btnKhachChu;
        private Button btnKhachVao;
        private Button btnQLBaiDoXe;
        private Button btnTaiKhoan;
        private Button btnKhachRa;
        private TabPage tabQLNhanVien;
        private TabControl tabControlAdmin;
        private Button btnTimKiemNhanVien;
        private TextBox txtTimKiemNhanVien;
        private DataGridView dgvNhanVien;
        private Button btnSua;
        private Button btnXoa;
        private PictureBox pictureBoxBackground;
    }
}