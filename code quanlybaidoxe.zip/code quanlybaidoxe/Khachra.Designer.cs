﻿namespace QuanLyBaiDoXe
{
    partial class Khachra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Khachra));
            txtBienSo = new TextBox();
            btnTimKiem = new Button();
            btnQuetKhuonMat = new Button();
            lblThongTinXe = new Label();
            btnXacNhan = new Button();
            imgKhachHang = new PictureBox();
            imgDebug = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)imgKhachHang).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgDebug).BeginInit();
            SuspendLayout();
            // 
            // txtBienSo
            // 
            txtBienSo.Location = new Point(50, 39);
            txtBienSo.Name = "txtBienSo";
            txtBienSo.Size = new Size(297, 27);
            txtBienSo.TabIndex = 0;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Location = new Point(353, 39);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(94, 29);
            btnTimKiem.TabIndex = 1;
            btnTimKiem.Text = "Tìm kiếm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // btnQuetKhuonMat
            // 
            btnQuetKhuonMat.Location = new Point(456, 317);
            btnQuetKhuonMat.Name = "btnQuetKhuonMat";
            btnQuetKhuonMat.Size = new Size(94, 29);
            btnQuetKhuonMat.TabIndex = 2;
            btnQuetKhuonMat.Text = "Quét";
            btnQuetKhuonMat.UseVisualStyleBackColor = true;
            btnQuetKhuonMat.Click += btnQuetKhuonMat_Click;
            // 
            // lblThongTinXe
            // 
            lblThongTinXe.AutoSize = true;
            lblThongTinXe.Location = new Point(425, 9);
            lblThongTinXe.Name = "lblThongTinXe";
            lblThongTinXe.Size = new Size(0, 20);
            lblThongTinXe.TabIndex = 4;
            // 
            // btnXacNhan
            // 
            btnXacNhan.Location = new Point(456, 352);
            btnXacNhan.Name = "btnXacNhan";
            btnXacNhan.Size = new Size(94, 29);
            btnXacNhan.TabIndex = 5;
            btnXacNhan.Text = "Xác nhận";
            btnXacNhan.UseVisualStyleBackColor = true;
            // 
            // imgKhachHang
            // 
            imgKhachHang.BackgroundImageLayout = ImageLayout.Stretch;
            imgKhachHang.Location = new Point(50, 81);
            imgKhachHang.Name = "imgKhachHang";
            imgKhachHang.Size = new Size(400, 300);
            imgKhachHang.SizeMode = PictureBoxSizeMode.StretchImage;
            imgKhachHang.TabIndex = 6;
            imgKhachHang.TabStop = false;
            // 
            // imgDebug
            // 
            imgDebug.BackgroundImageLayout = ImageLayout.Stretch;
            imgDebug.Location = new Point(556, 81);
            imgDebug.Name = "imgDebug";
            imgDebug.Size = new Size(400, 300);
            imgDebug.SizeMode = PictureBoxSizeMode.StretchImage;
            imgDebug.TabIndex = 7;
            imgDebug.TabStop = false;
            // 
            // Khachra
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(982, 503);
            Controls.Add(imgDebug);
            Controls.Add(imgKhachHang);
            Controls.Add(btnXacNhan);
            Controls.Add(lblThongTinXe);
            Controls.Add(btnQuetKhuonMat);
            Controls.Add(btnTimKiem);
            Controls.Add(txtBienSo);
            Name = "Khachra";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Khachra";
            Load += Khachra_Load;
            ((System.ComponentModel.ISupportInitialize)imgKhachHang).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgDebug).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
        private void Khachra_Load(object sender, EventArgs e)
        {

        }
        #endregion

        private TextBox txtBienSo;
        private Button btnTimKiem;
        private Button btnQuetKhuonMat;
        private Label lblThongTinXe;
        private Button btnXacNhan;
        private PictureBox imgKhachHang;
        private PictureBox imgDebug;
    }
}