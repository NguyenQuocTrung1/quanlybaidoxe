﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBaiDoXe
{
    public partial class QuanLyBaiDo : Form
    {
        private string connectionString = "Server=NGUYENQUOCTRUNG\\SQLEXPRESS04;Database=face_db;Trusted_Connection=True;TrustServerCertificate=True;";
        public QuanLyBaiDo()
        {
            InitializeComponent();
            LoadParkingData();
        }
        private void LoadParkingData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT id, owner_name, plate_number, check_in, check_out, fee FROM parking_history";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvXeGui.DataSource = dt;
            }
        }
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string tenKhach = txtChuXe.Text.Trim();
            if (string.IsNullOrEmpty(tenKhach))
            {
                MessageBox.Show("Vui lòng nhập tên khách để tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT id, name, plate_number, check_in, check_out FROM parking_history WHERE name LIKE @tenKhach";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.SelectCommand.Parameters.AddWithValue("@tenKhach", "%" + tenKhach + "%");
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvXeGui.DataSource = dt;
            }
        }

        private void QuanLyBaiDo_Load(object sender, EventArgs e)
        {

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvXeGui.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvXeGui.SelectedRows[0].Cells["id"].Value);
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM parking_history WHERE id = @id";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadParkingData();
                MessageBox.Show("Đã xóa xe khỏi danh sách!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Vui lòng chọn xe để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LoadParkingData();
        }
    }
}
