﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBaiDoXe
{
    public partial class TaiKhoan : Form
    {
        private readonly string connectionString = "Server=NGUYENQUOCTRUNG\\SQLEXPRESS04;Database=face_db;Trusted_Connection=True;TrustServerCertificate=True;";

        public TaiKhoan()
        {
            InitializeComponent();
            HienThiDangNhap();
            txtMatKhau.PasswordChar = '*';
        }
        private void HienThiDangNhap()
        {
            lblTitle.Text = "Đăng Nhập";
            lblVaiTro.Visible = false;
            cmbVaiTro.Visible = false;
            btnDangnhap.Visible = true;
            btnDangky.Visible = false;
            btnSwitchToDangKy.Visible = true;
            btnSwitchToDangNhap.Visible = false;
        }
        private void HienThiDangKy()
        {
            lblTitle.Text = "Đăng Ký";
            lblVaiTro.Visible = true;
            cmbVaiTro.Visible = true;
            btnDangnhap.Visible = false;
            btnDangky.Visible = true;
            btnSwitchToDangKy.Visible = false;
            btnSwitchToDangNhap.Visible = true;
        }
        private void TaiKhoan_Load(object sender, EventArgs e)
        {

        }

        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            string tenDangNhap = txtTenDangNhap.Text;
            string matKhau = txtMatKhau.Text;

            if (string.IsNullOrWhiteSpace(tenDangNhap) || string.IsNullOrWhiteSpace(matKhau))
            {
                MessageBox.Show("Vui lòng nhập tài khoản và mật khẩu!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT vai_tro FROM nguoi_dung WHERE ten_dang_nhap = @tenDangNhap AND mat_khau = @matKhau";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@tenDangNhap", tenDangNhap);
                cmd.Parameters.AddWithValue("@matKhau", matKhau);

                object result = cmd.ExecuteScalar();
                string vaiTro = result as string ?? "Nhân Viên";

                if (result != null)
                {
                    MessageBox.Show($"Đăng nhập thành công với vai trò {vaiTro}!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    FormChinh formChinh = new FormChinh(vaiTro); // Mở form chính
                    formChinh.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sai tài khoản hoặc mật khẩu!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDangky_Click(object sender, EventArgs e)
        {
            string tenDangNhap = txtTenDangNhap.Text;
            string matKhau = txtMatKhau.Text;
            string vaiTro = cmbVaiTro.SelectedItem?.ToString() ?? "";

            if (string.IsNullOrWhiteSpace(tenDangNhap) || string.IsNullOrWhiteSpace(matKhau) || string.IsNullOrWhiteSpace(vaiTro))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string checkQuery = "SELECT COUNT(*) FROM nguoi_dung WHERE ten_dang_nhap = @tenDangNhap";
                SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                checkCmd.Parameters.AddWithValue("@tenDangNhap", tenDangNhap);

                int count = (int)checkCmd.ExecuteScalar();
                if (count > 0)
                {
                    MessageBox.Show("Tên đăng nhập đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string insertQuery = "INSERT INTO nguoi_dung (ten_dang_nhap, mat_khau, vai_tro) VALUES (@tenDangNhap, @matKhau, @vaiTro)";
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@tenDangNhap", tenDangNhap);
                cmd.Parameters.AddWithValue("@matKhau", matKhau);
                cmd.Parameters.AddWithValue("@vaiTro", vaiTro);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Đăng ký thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    HienThiDangNhap(); // Chuyển về giao diện Đăng nhập
                }
                else
                {
                    MessageBox.Show("Đăng ký thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSwitchToDangNhap_Click(object sender, EventArgs e)
        {
            HienThiDangNhap();
        }

        private void btnSwitchToDangKy_Click(object sender, EventArgs e)
        {
            HienThiDangKy();
        }
    }
}
